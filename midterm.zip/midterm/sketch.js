
function preload(){
    bgImage = loadImage("images/background.png");
}

function setup() {
    var canvas = createCanvas(500, 500);


}


function draw(){
    background("lightblue");

}






